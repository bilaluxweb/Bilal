const roles = [
  "Web Designer",
  "Graphic Designer",
  "UI/UX Designer",
  "Shopify Expert",
  "WordPress Expert",
  "Canva Expert"
];
let roleIndex = 0, charIdx = 0, deleting = false;
const typedEl = document.getElementById("typed");
function typeEffect() {
  const current = roles[roleIndex];
  if (!deleting) {
    typedEl.textContent = current.substring(0, charIdx++);
    if (charIdx > current.length) {
      deleting = true;
      setTimeout(typeEffect, 1200);
      return;
    }
  } else {
    typedEl.textContent = current.substring(0, charIdx--);
    if (charIdx === 0) {
      deleting = false;
      roleIndex = (roleIndex + 1) % roles.length;
    }
  }
  setTimeout(typeEffect, deleting ? 50 : 120);
}
if (typedEl) typeEffect();

const hamburger = document.getElementById("hamburger");
const navList = document.getElementById("nav-list");
hamburger.addEventListener("click", () => {
  navList.classList.toggle("open");
});
